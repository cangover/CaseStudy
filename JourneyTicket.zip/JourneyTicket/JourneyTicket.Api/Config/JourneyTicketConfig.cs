﻿namespace JourneyTicket.Api.Config
{
	public class JourneyTicketConfig
	{
        public required string Authorization { get; set; }
        public required string Port { get; set; }
        public required string BaseUrl { get; set; }
        public required string GetLocations { get; set; }
        public required string GetJourneys { get; set; }
        public required string GetSession { get; set; }
        public required string Token { get; set; }
        public required int SessionType { get; set; }
    }
}