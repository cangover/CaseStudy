﻿using System.Net.Http.Headers;
using System.Text;
using JourneyTicket.Api.Common;
using JourneyTicket.Api.Config;
using JourneyTicket.Api.Enums;
using JourneyTicket.Api.Models.Request;
using JourneyTicket.Api.Models.Response;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace JourneyTicket.Api.Service
{
    public interface IClientService
    {
        Task<GetSessionResponse> GetSession();
        Task<GetLocationsResponse> GetBusLocations(GetLocationsRequest request);
        Task<GetJourneysResponse> GetBusJourneys(GetJourneysRequest request);
    }

    public class ClientService : IClientService
	{
        private readonly JourneyTicketConfig _config;
        private readonly ILogger<ClientService> _logger;
        private readonly ICacheManager _cacheManager;
        private readonly HttpClient _httpClient;

        public ClientService(IOptions<JourneyTicketConfig> config, ILogger<ClientService> logger, ICacheManager cacheManager, HttpClient? httpClient = null)
        {
            _config = config.Value;
            _logger = logger;
            _cacheManager = cacheManager;
            if (httpClient == null)
            {
                _httpClient = new()
                {
                    BaseAddress = new Uri(_config.BaseUrl)
                };
            }
            else
            {
                _httpClient = httpClient;
            }
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            _httpClient.DefaultRequestHeaders.Add("Authorization", _config.Token);
        }

        public async Task<GetSessionResponse> GetSession()
        {
            try
            {
                BrowserData browserData = await _cacheManager.Get<BrowserData>("browser");
                if (browserData == null)
                    return new GetSessionResponse() { Status = ResponseStatus.NoResponse };

                var request = new GetSessionRequest
                {
                    Type = _config.SessionType,
                    ConnectionInfo = new Connection
                    {
                        IpAddress = "165.114.41.21",
                        Port = _config.Port,
                    },
                    BrowserInfo = new Browser
                    {
                        Name = browserData.Name,
                        Version = browserData.Version
                    }
                };

                var httpResponse = await _httpClient.PostAsync(_config.GetSession, new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json"));
                httpResponse.EnsureSuccessStatusCode();

                var response = JsonConvert.DeserializeObject<GetSessionResponse>(await httpResponse.Content.ReadAsStringAsync());

                if (response?.Status == ResponseStatus.Success)
                    await _cacheManager.Set("session", response.Data);

                return response ?? new GetSessionResponse() { Status = ResponseStatus.NoResponse };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetSessionResponse method.");
                return new GetSessionResponse() { Status = ResponseStatus.NoResponse };
            }
        }

        public async Task<GetLocationsResponse> GetBusLocations(GetLocationsRequest request)
        {
            try
            {
                var httpResponse = await _httpClient.PostAsync(_config.GetLocations, new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json"));
                httpResponse.EnsureSuccessStatusCode();

                var response = JsonConvert.DeserializeObject<GetLocationsResponse>(await httpResponse.Content.ReadAsStringAsync());
                if (response != null)
                    response.Data = response.Data.Take(25).ToList();

                return response ?? new GetLocationsResponse() { Status = ResponseStatus.NoResponse };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetBusLocations method.");
                return new GetLocationsResponse() { Status = ResponseStatus.NoResponse };
            }
        }

        public async Task<GetJourneysResponse> GetBusJourneys(GetJourneysRequest request)
        {
            try
            {
                await Task.WhenAll(
                    _cacheManager.Set("originId", request.Data.OriginId),
                    _cacheManager.Set("destinationId", request.Data.DestinationId),
                    _cacheManager.Set("selectedDate", request.Data.DepartureDate)
                );

                var httpResponse = await _httpClient.PostAsync(_config.GetJourneys, new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json"));
                httpResponse.EnsureSuccessStatusCode();

                var response = JsonConvert.DeserializeObject<GetJourneysResponse>(await httpResponse.Content.ReadAsStringAsync());
                if (response != null)
                    response.Data = response.Data.OrderBy(i => i.Journey.Departure).ToList();

                return response ?? new GetJourneysResponse() { Status = ResponseStatus.NoResponse };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetBusJourneys method");
                return new GetJourneysResponse() { Status = ResponseStatus.NoResponse };
            }
        }
    }
}