﻿using JourneyTicket.Api.Common;
using JourneyTicket.Api.Enums;
using Newtonsoft.Json;

namespace JourneyTicket.Api.Models.Response
{
	public class GetSessionResponse
	{
        [JsonProperty("status")]
        public ResponseStatus Status { get; set; }

        [JsonProperty("data")]
        public SessionData Data { get; set; }
    }
}