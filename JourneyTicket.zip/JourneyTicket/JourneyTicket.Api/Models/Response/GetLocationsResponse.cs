﻿using JourneyTicket.Api.Enums;
using Newtonsoft.Json;

namespace JourneyTicket.Api.Models.Response
{
	public class GetLocationsResponse
	{
        [JsonProperty("status")]
        public ResponseStatus Status { get; set; }
        [JsonProperty("data")]
        public List<LocationData> Data { get; set; } = new();
    }

    public class LocationData
    {
        [JsonProperty("id")]
        public int Id { get; set; }
        [JsonProperty("name")]
        public required string Name { get; set; }
    }
}