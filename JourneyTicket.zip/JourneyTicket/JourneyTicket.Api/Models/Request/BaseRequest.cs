﻿using JourneyTicket.Api.Common;
using Newtonsoft.Json;

namespace JourneyTicket.Api.Models.Request
{
	public class BaseRequest
	{
        [JsonProperty("device-session")]
        public required SessionData DeviceSession { get; set; }
        [JsonProperty("date")]
        public DateTime Date { get; set; } = DateTime.Now;
        [JsonProperty("language")]
        public string Language { get; set; } = "tr-TR";
    }
}