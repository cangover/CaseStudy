﻿using System;
using Newtonsoft.Json;

namespace JourneyTicket.Api.Models.Request
{
	public class GetJourneysRequest : BaseRequest
    {
        [JsonProperty("data")]
        public required Data Data { get; set; }
    }

    public class Data
    {
        [JsonProperty("origin-id")]
        public int OriginId { get; set; }
        [JsonProperty("destination-id")]
        public int DestinationId { get; set; }
        [JsonProperty("departure-date")]
        public required DateTime DepartureDate { get; set; }
    }
}
