﻿using Newtonsoft.Json;

namespace JourneyTicket.Api.Models.Request
{
	public class GetLocationsRequest : BaseRequest
    {
        [JsonProperty("data")]
        public string? Data { get; set; }
    }
}