﻿namespace JourneyTicket.Api.Enums
{
    public enum ResponseStatus
    {
        Success,
        InvalidDepartureDate,
        InvalidRoute,
        InvalidLocation,
        Timeout,
        NoResponse
    }
}