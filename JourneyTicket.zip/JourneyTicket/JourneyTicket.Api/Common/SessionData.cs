﻿using Newtonsoft.Json;

namespace JourneyTicket.Api.Common
{
	public class SessionData
	{
        [JsonProperty("session-id")]
        public string SessionId { get; set; }
        [JsonProperty("device-id")]
        public string DeviceId { get; set; }
    }
}