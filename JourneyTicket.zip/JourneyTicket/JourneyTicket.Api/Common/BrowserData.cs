﻿using System;
namespace JourneyTicket.Api.Common
{
	public class BrowserData
	{
        public string Name { get; set; }
        public string Version { get; set; }
    }
}