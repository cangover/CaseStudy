﻿using Microsoft.Extensions.Caching.Memory;

namespace JourneyTicket.Api.Common
{
    public interface ICacheManager
    {
        Task<T> Get<T>(string key);
        Task Set<T>(string key, T value);
    }

    public class CacheManager : ICacheManager
    {
        private readonly IMemoryCache _memoryCache;

        public CacheManager(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public Task<T> Get<T>(string key) => Task.FromResult(_memoryCache.Get<T>(key));

        public Task Set<T>(string key, T value)
        {
            _memoryCache.Set(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTimeOffset.Now.AddDays(1),
                Priority = CacheItemPriority.Normal
            });
            return Task.CompletedTask;
        }
    }
}