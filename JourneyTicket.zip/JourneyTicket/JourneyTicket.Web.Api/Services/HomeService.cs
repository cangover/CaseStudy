﻿using AutoMapper;
using JourneyTicket.Web.Api.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Globalization;
using JourneyTicket.Api.Common;
using JourneyTicket.Api.Service;
using JourneyTicket.Api.Models.Request;
using JourneyTicket.Api.Models.Response;
using JourneyTicket.Api.Enums;

namespace JourneyTicket.Web.Api.Services
{
    public interface IHomeService
    {
        public Task<IndexViewModel> GetBusLocations(bool isReturnPage);
        public Task<JourneyIndexViewModel> GetJourney(IndexViewModel model);
        public Task SetJourneyDetailCache(IndexViewModel model);
        public Task GetBrowserInformation(string userAgent);
    }

    public class HomeService : IHomeService
    {
        private readonly ICacheManager _cacheManager;
        private readonly IClientService _clientService;
        private readonly IMapper _mapper;
        private readonly ILogger<HomeService> _logger;
        public HomeService(ICacheManager cacheManager, IClientService clientService, IMapper mapper, ILogger<HomeService> logger)
        {
            _cacheManager = cacheManager;
            _clientService = clientService;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<IndexViewModel> GetBusLocations(bool isReturnPage)
        {
            var viewModel = new IndexViewModel
            {
                Origin = await _cacheManager.Get<List<SelectListItem>>("origin"),
                Destination = await _cacheManager.Get<List<SelectListItem>>("destination")
            };

            if (viewModel.Origin == null || viewModel.Destination == null)
                await GetLocations(viewModel);

            return await UpdateIndexViewModel(viewModel, isReturnPage);
        }

        public async Task<JourneyIndexViewModel> GetJourney(IndexViewModel model)
        {
            var deviceSession = await GetSession() ?? new SessionData();

            if (deviceSession != null)
            {
                var response = await _clientService.GetBusJourneys(new GetJourneysRequest
                {
                    DeviceSession = deviceSession,
                    Data = new Data
                    {
                        DepartureDate = model.DepatureDate,
                        DestinationId = model.SelectedDestination.Value,
                        OriginId = model.SelectedOrigin.Value
                    }
                });

                var viewModel = _mapper.Map<JourneyIndexViewModel>(response);
                await SetJourneyViewHeader(viewModel, model);

                return viewModel;
            }

            return new JourneyIndexViewModel();
        }

        public Task SetJourneyDetailCache(IndexViewModel model)
        {
            return Task.WhenAll(
                _cacheManager.Set("selectedOrigin", model.SelectedOrigin),
                _cacheManager.Set("selectedDestination", model.SelectedDestination),
                _cacheManager.Set("selectedDate", model.DepatureDate)
            );
        }

        private async Task<IndexViewModel> UpdateIndexViewModel(IndexViewModel viewModel, bool isReturnPage)
        {
            if (isReturnPage)
            {
                viewModel.SelectedOrigin = await _cacheManager.Get<int>("selectedOrigion");
                viewModel.SelectedDestination = await _cacheManager.Get<int>("selectedDestination");
                viewModel.DepatureDate = await _cacheManager.Get<DateTime>("selectedDate");
            }
            else
            {
                viewModel.DepatureDate = DateTime.Now.AddDays(1);
            }
            return viewModel;
        }


        private async Task<SessionData> GetSession()
        {
            var cachedSession = await _cacheManager.Get<SessionData>("session");

            if (cachedSession != null) return cachedSession;

            GetSessionResponse session = await _clientService.GetSession();

            if (session.Status == ResponseStatus.Success)
            {
                cachedSession = new SessionData
                {
                    DeviceId = session.Data.DeviceId,
                    SessionId = session.Data.SessionId
                };
            }

            return cachedSession;
        }
        
        private async Task GetLocations(IndexViewModel viewModel)
        {
            SessionData deviceSession = await GetSession() ?? new SessionData();
            if (deviceSession != null)
            {
                GetLocationsResponse response = await _clientService.GetBusLocations(new GetLocationsRequest
                {
                    DeviceSession = deviceSession
                });

                List<SelectListItem> origin = await GetLocationList(response.Data, "Avrupa");
                List<SelectListItem> destination = await GetLocationList(response.Data, "Ankara");

                await _cacheManager.Set("origion", origin);
                await _cacheManager.Set("destination", destination);

                viewModel.Origin = origin;
                viewModel.Destination = destination;
            }
        }

        private async Task SetJourneyViewHeader(JourneyIndexViewModel viewModel, IndexViewModel model)
        {
            var originLocation = await _cacheManager.Get<List<SelectListItem>>("origin");
            viewModel.OriginLocation = originLocation?.Find(item => item.Value == model.SelectedOrigin.ToString())?.Text;

            var destinationLocation = await _cacheManager.Get<List<SelectListItem>>("destination");
            viewModel.DestinationLocation = destinationLocation?.Find(item => item.Value == model.SelectedDestination.ToString())?.Text;

            viewModel.SelectedDate = model.DepatureDate.ToString("d MMMM dddd", CultureInfo.CreateSpecificCulture("tr-TR"));
        }
        
        private async Task<List<SelectListItem>> GetLocationList(List<LocationData> data, string condition)
        {
            if (data != null)
            {
                return data.Select(s => new SelectListItem()
                {
                    Text = s.Name,
                    Value = s.Id.ToString(),
                    Selected = condition == "Avrupa" ? s.Name.Contains("Avrupa") : s.Name.Equals("Ankara")
                }).ToList();
            }
            else
            {
                return null;
            }
        }

        public async Task GetBrowserInformation(string userAgent)
        {
            try
            {
                BrowserData browserData = await _cacheManager.Get<BrowserData>("browser");

                if (browserData != null) return;

                if (string.IsNullOrEmpty(userAgent)) return;

                string[] userAgentInfo = userAgent.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);

                if (userAgentInfo.Length >= 3)
                {
                    browserData = new BrowserData();

                    browserData.Name = userAgentInfo[2];

                    if (userAgentInfo.Length >= 4)
                    {
                        browserData.Version = userAgentInfo[3];
                    }
                }

                await _cacheManager.Set("browser", browserData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetBrowserInformation metodunda hata alındı.");
            }
        }
    }
}
