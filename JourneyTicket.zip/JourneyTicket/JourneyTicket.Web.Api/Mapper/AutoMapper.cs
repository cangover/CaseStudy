﻿using AutoMapper;
using JourneyTicket.Api.Models.Response;
using JourneyTicket.Web.Api.Models;

namespace JourneyTicket.Web.Api.Mapper
{
	public class AutoMapper : Profile
    {
        public AutoMapper()
        {
            CreateMap<Journey, JourneyModel>()
                .ForMember(dest => dest.Arrival, opt => opt.MapFrom(src => src.Arrival.ToString("HH:mm")))
                .ForMember(dest => dest.Departure, opt => opt.MapFrom(src => src.Departure.ToString("HH:mm")))
                .ReverseMap();
            CreateMap<GetJourneysResponse, JourneyIndexViewModel>()
                .ForMember(dest => dest.Journeys, opt => opt.MapFrom(src => src.Data.Select(x => x.Journey).ToList()))
                .ReverseMap();
        }
    }
}