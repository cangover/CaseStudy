﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace JourneyTicket.Web.Api.Models
{
    public class IndexViewModel
    {
        public IndexViewModel()
        {
            Origin = new List<SelectListItem>();
            Destination = new List<SelectListItem>();
        }
        [NotEqual("SelectedDestination", ErrorMessage = "Nereden ve Nereye seçimi aynı olamaz.")]
        public int? SelectedOrigin { get; set; }
        public int? SelectedDestination { get; set; }
        [MinDateToday(ErrorMessage = "Tarih seçimi bugünden küçük olamaz.")]
        public DateTime DepatureDate { get; set; }
        public List<SelectListItem> Origin { get; set; }
        public List<SelectListItem> Destination { get; set; }
    }

    public class MinDateTodayAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value is DateTime date)
            {
                return date.Date >= DateTime.Now.Date;
            }
            return false;
        }
    }

    public class NotEqualAttribute : ValidationAttribute
    {
        private readonly string otherProperty;

        public NotEqualAttribute(string otherProperty)
        {
            this.otherProperty = otherProperty;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var propertyInfo = validationContext.ObjectType.GetProperty(otherProperty);
            if (propertyInfo == null)
            {
                return new ValidationResult($"Property with name {otherProperty} not found.");
            }

            var otherValue = propertyInfo.GetValue(validationContext.ObjectInstance);

            if (value == null && otherValue == null)
            {
                return ValidationResult.Success;
            }

            if (!value.Equals(otherValue))
            {
                return ValidationResult.Success;
            }

            return new ValidationResult(ErrorMessage ?? "The values must not be equal.");
        }
    }
}