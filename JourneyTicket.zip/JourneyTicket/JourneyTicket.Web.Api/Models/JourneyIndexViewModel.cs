﻿namespace JourneyTicket.Web.Api.Models
{
	public class JourneyIndexViewModel
	{
        public string OriginLocation { get; set; }
        public string DestinationLocation { get; set; }
        public string SelectedDate { get; set; }
        public List<JourneyModel> Journeys { get; set; } = new();
    }
    public class JourneyModel
    {
        public string Origin { get; set; }
        public string Destination { get; set; }
        public string Currency { get; set; }
        public string Price { get; set; }
        public string Arrival { get; set; }
        public string Departure { get; set; }
    }
}