﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using JourneyTicket.Web.Api.Models;
using JourneyTicket.Web.Api.Services;

namespace JourneyTicket.Web.Api.Controllers;

public class HomeController : Controller
{
    private readonly IHomeService _homeService;

    public HomeController(IHomeService homeService)
    {
        _homeService = homeService;
    }

    public async Task<IActionResult> Index(bool isReturnPage)
    {
        string userAgent = Request.Headers["User-Agent"];
        if (string.IsNullOrEmpty(userAgent))
            return View("Error");

        await _homeService.GetBrowserInformation(userAgent);
        var viewModel = await _homeService.GetBusLocations(isReturnPage);

        return View(viewModel);
    }

    [HttpPost]
    public async Task<IActionResult> GetJourneys(IndexViewModel model)
    {
        await _homeService.SetJourneyDetailCache(model);

        if (ModelState.IsValid)
            return View("JourneyIndex", await _homeService.GetJourney(model));
        else
            return View("Index", await _homeService.GetBusLocations(true));
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() => View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}